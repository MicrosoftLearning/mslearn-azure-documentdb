#!/usr/bin/env python3
import json, re, sys
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]

def load(rel):
    with open(ROOT / rel, encoding="utf-8") as f:
        return json.load(f)

def oid(v):
    return v.get("$oid") if isinstance(v, dict) else None

def dstr(v):
    return v.get("$date") if isinstance(v, dict) else None

def dt(s):
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)

def wc(s):
    return len(re.findall(r"\b[\w'-]+\b", s))

def sc(s):
    return len([x for x in re.split(r"(?<=[.!?])\s+", s.strip()) if x])

def round2(x):
    return round(float(x) + 1e-9, 2)

def price_bounds(p):
    pt = p["productType"]
    cat = p["category"]["name"]
    if pt == "bike":
        return (500, 3600)
    if pt == "clothing":
        return (15, 90)
    if pt == "accessory":
        return (5, 200)
    if pt == "component":
        if "Frame" in cat:
            return (250, 1400)
        if cat == "Wheels":
            return (60, 350)
        if cat == "Tires and Tubes":
            return (3, 35)
        if cat in {"Handlebars", "Pedals", "Saddles"}:
            return (20, 120)
        if cat in {"Bottom Brackets", "Brakes", "Chains", "Cranksets", "Derailleurs", "Forks", "Headsets"}:
            return (15, 200)
    return (0, 999999)

def inv_bounds(p):
    return {
        "bike": (5, 60),
        "component": (20, 200),
        "accessory": (50, 500),
        "clothing": (30, 300)
    }[p["productType"]]

def prefix(text, n=8, first=True):
    toks = re.findall(r"\w+", text.lower())
    return " ".join(toks[:n] if first else toks[-n:])

errors = []

collections = {
    "categories": load("collections/categories.json"),
    "tags": load("collections/tags.json"),
    "products": load("collections/products.json"),
    "customers": load("collections/customers.json"),
    "orders": load("collections/orders.json"),
    "reviews": load("collections/reviews.json"),
    "inventory": load("collections/inventory.json"),
    "ordersArchive": load("collections/ordersArchive.json"),
}

expected_counts = {
    "categories": 37,
    "tags": 50,
    "products": 1000,
    "customers": 249,
    "orders": 4000,
    "reviews": 5000,
    "inventory": 900,
    "ordersArchive": 1613,
}
for name, expected in expected_counts.items():
    actual = len(collections[name])
    if actual != expected:
        errors.append(f"{name} count {actual} != {expected}")

oid_re = re.compile(r"^[0-9a-f]{24}$")
date_re = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")

def walk_ext(obj, path):
    if isinstance(obj, dict):
        if "$oid" in obj and (set(obj) != {"$oid"} or not isinstance(obj["$oid"], str) or not oid_re.match(obj["$oid"])):
            errors.append(f"{path}: invalid $oid")
        if "$date" in obj and (set(obj) != {"$date"} or not isinstance(obj["$date"], str) or not date_re.match(obj["$date"])):
            errors.append(f"{path}: invalid $date")
        for k, v in obj.items():
            walk_ext(v, f"{path}.{k}")
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            walk_ext(v, f"{path}[{i}]")

for name, coll in collections.items():
    walk_ext(coll, name)
    ids = [oid(doc["_id"]) for doc in coll]
    if len(ids) != len(set(ids)):
        errors.append(f"{name} contains duplicate _id values")

categories = collections["categories"]
tags = collections["tags"]
products = collections["products"]
customers = collections["customers"]
orders = collections["orders"]
reviews = collections["reviews"]
inventory = collections["inventory"]
archives = collections["ordersArchive"]

cat_by_id = {oid(c["_id"]): c for c in categories}
tag_by_name = {t["name"]: t for t in tags}
tag_by_id = {oid(t["_id"]): t for t in tags}
prod_by_id = {oid(p["_id"]): p for p in products}
cust_by_id = {oid(c["_id"]): c for c in customers}
order_by_id = {oid(o["_id"]): o for o in orders}
archive_by_id = {oid(a["_id"]): a for a in archives}

approved_names = set((ROOT / "validation" / "approved-fictitious-fullnames.txt").read_text(encoding="utf-8").splitlines())
customer_names = {c["fullName"] for c in customers}
if customer_names != approved_names:
    errors.append("Customer fullName values do not exactly match approved FNF full names")

for p in products:
    pid = oid(p["_id"])
    cid = oid(p["category"]["_id"])
    if cid not in cat_by_id:
        errors.append(f"Product {pid} references missing category")
    else:
        if p["category"]["name"] != cat_by_id[cid]["name"] or p["parentCategory"] != cat_by_id[cid]["parentCategory"]:
            errors.append(f"Product {p['sku']} category extended reference mismatch")
    if re.search(r"\bVariant\s+\d+\b", p["name"]):
        errors.append(f"Product {p['sku']} still has Variant suffix")
    if re.match(r"^[A-Z]{2}-X0\d{3}", p["sku"]):
        errors.append(f"Product {p['sku']} still has generated X0 SKU pattern")
    if not (3 <= len(p["tags"]) <= 6) or any(t not in tag_by_name for t in p["tags"]):
        errors.append(f"Product {p['sku']} has invalid tags")
    lo, hi = price_bounds(p)
    if not (lo <= p["price"] <= hi):
        errors.append(f"Product {p['sku']} price {p['price']} outside {lo}-{hi}")
    ilo, ihi = inv_bounds(p)
    if not (ilo <= p["inventory"] <= ihi):
        errors.append(f"Product {p['sku']} inventory {p['inventory']} outside {ilo}-{ihi}")
    desc = p["description"]
    if not (2 <= sc(desc) <= 3):
        errors.append(f"Product {p['sku']} description must be 2-3 sentences")
    low = desc.lower()
    for term in ["exercise", "learner", "filtering", "comparison", "dataset", "this item combines", "configuration intended"]:
        if term in low:
            errors.append(f"Product {p['sku']} description contains prohibited term: {term}")
if len({p["sku"] for p in products}) != len(products):
    errors.append("Duplicate product SKUs")
if len({p["description"] for p in products}) != len(products):
    errors.append("Duplicate product descriptions")

outliers = [p for p in products if p.get("isOutlier")]
if {p["name"] for p in outliers} != {"Touring-1000 Yellow, 54", "Road-150 Red, 52", "Sport-100 Helmet, Black, M", "Mountain-100 Silver, 44"}:
    errors.append("Outlier product set does not match prompt")

terminal = {"delivered", "cancelled", "returned"}
nonterminal = {"pending", "confirmed", "processing", "shipped"}
cutoff = dt("2026-01-16T00:00:00Z")
full_orders = 0
stub_orders = 0

for o in orders:
    oidv = oid(o["_id"])
    status = o["status"]
    od = dt(dstr(o["orderDate"]))
    should_full = od >= cutoff or status in nonterminal
    if o["isFullyLoaded"]:
        full_orders += 1
    else:
        stub_orders += 1
    if o["isFullyLoaded"] != should_full:
        errors.append(f"Order {oidv} violates full/stub date-status rule")
    cust = cust_by_id.get(oid(o["customerId"]))
    if not cust:
        errors.append(f"Order {oidv} references missing customer")
        continue
    if o["customerName"] != cust["fullName"] or o["customerEmail"] != cust["email"]:
        errors.append(f"Order {oidv} customer denormalized fields mismatch")
    if o["isFullyLoaded"]:
        for f in ["items", "shippingAddress", "shipDate", "subtotal", "shipping", "tax", "total", "itemCount"]:
            if f not in o:
                errors.append(f"Full order {oidv} missing {f}")
        for f in ["archiveId", "archiveCollection", "archiveLocation", "archivedAt"]:
            if f in o:
                errors.append(f"Full order {oidv} should not contain {f}")
        expected_addr = {k: cust["addresses"][0][k] for k in ["street", "city", "state", "country", "zipCode"]}
        if o.get("shippingAddress") != expected_addr:
            errors.append(f"Full order {oidv} shippingAddress does not match customer's first address snapshot")
        subtotal = round2(sum(it["price"] * it["quantity"] for it in o["items"]))
        shipping = 0.0 if subtotal > 100 else (5.99 if subtotal >= 50 else 12.99)
        tax = round2(subtotal * 0.095)
        total = round2(subtotal + shipping + tax)
        if abs(o["subtotal"] - subtotal) > 0.01 or abs(o["shipping"] - shipping) > 0.01 or abs(o["tax"] - tax) > 0.01 or abs(o["total"] - total) > 0.01:
            errors.append(f"Full order {oidv} financial totals are incorrect")
        if o["itemCount"] != sum(it["quantity"] for it in o["items"]):
            errors.append(f"Full order {oidv} itemCount is incorrect")
        if not (1 <= len(o["items"]) <= 5):
            errors.append(f"Full order {oidv} items array length outside 1-5")
        for it in o["items"]:
            p = prod_by_id.get(oid(it["productId"]))
            if not p or it["sku"] != p["sku"] or it["name"] != p["name"] or abs(it["price"] - p["price"]) > 0.01:
                errors.append(f"Order {oidv} item product denormalized fields mismatch")
    else:
        if o.get("archiveLocation") != "ordersArchive" or "archiveCollection" in o:
            errors.append(f"Stub order {oidv} archive fields are incorrect")
        for f in ["items", "shippingAddress", "shipDate", "subtotal", "shipping", "tax"]:
            if f in o:
                errors.append(f"Stub order {oidv} contains full-order field {f}")
        a = archive_by_id.get(oid(o["archiveId"]))
        if not a:
            errors.append(f"Stub order {oidv} references missing archive")
        else:
            if a["total"] != o["total"] or a["itemCount"] != o["itemCount"] or a["customerName"] != o["customerName"] or dstr(a["orderDate"]) != dstr(o["orderDate"]):
                errors.append(f"Stub order {oidv} archive fields mismatch")

for a in archives:
    aid = oid(a["_id"])
    if "label" in a.get("shippingAddress", {}):
        errors.append(f"Archive {aid} shippingAddress contains label")
    subtotal = round2(sum(it["price"] * it["quantity"] for it in a["items"]))
    shipping = 0.0 if subtotal > 100 else (5.99 if subtotal >= 50 else 12.99)
    tax = round2(subtotal * 0.095)
    total = round2(subtotal + shipping + tax)
    if abs(a["subtotal"] - subtotal) > 0.01 or abs(a["shipping"] - shipping) > 0.01 or abs(a["tax"] - tax) > 0.01 or abs(a["total"] - total) > 0.01:
        errors.append(f"Archive {aid} financial totals are incorrect")

orders_by_customer = defaultdict(list)
for o in orders:
    orders_by_customer[oid(o["customerId"])].append(o)
for c in customers:
    cid = oid(c["_id"])
    recent = sorted(orders_by_customer[cid], key=lambda o: dstr(o["orderDate"]), reverse=True)[:5]
    if c["orderCount"] != len(orders_by_customer[cid]):
        errors.append(f"Customer {c['fullName']} orderCount mismatch")
    if [oid(x["_id"]) for x in c["recentOrders"]] != [oid(x["_id"]) for x in recent]:
        errors.append(f"Customer {c['fullName']} recentOrders mismatch")

review_by_product = defaultdict(list)
title_counts = Counter()
body_counts = Counter()
rating_counts = Counter()
verified_count = 0
prohibited_review = [
    "the details i paid attention", "because those are the parts", "for this review",
    "i evaluated", "the rating reflects", "i reviewed", "would keep the same category",
    "check the specific size and compatibility", "best ever", "perfect", "unmatched",
    "incredible", "amazing", "last weekend", "yesterday", "last week", "today"
]
for r in reviews:
    rid = oid(r["_id"])
    pid = oid(r["productId"])
    cid = oid(r["customerId"])
    if pid not in prod_by_id:
        errors.append(f"Review {rid} references missing product")
    if cid not in cust_by_id or r["customerName"] != cust_by_id[cid]["fullName"]:
        errors.append(f"Review {rid} customerName mismatch")
    title_counts[r["title"]] += 1
    body_counts[r["body"]] += 1
    rating_counts[r["rating"]] += 1
    verified_count += 1 if r["verified"] else 0
    if not (5 <= wc(r["title"]) <= 10):
        errors.append(f"Review {rid} title word count invalid")
    if not (40 <= wc(r["body"]) <= 120):
        errors.append(f"Review {rid} body word count invalid")
    if "\n" in r["body"] or not (2 <= sc(r["body"]) <= 4):
        errors.append(f"Review {rid} body sentence/paragraph shape invalid")
    if any(p in (r["title"] + " " + r["body"]).lower() for p in prohibited_review):
        errors.append(f"Review {rid} contains prohibited review phrase")
    cd = dt(dstr(r["createdAt"]))
    if not (dt("2025-06-01T00:00:00Z") <= cd <= dt("2026-04-15T23:59:59Z")):
        errors.append(f"Review {rid} createdAt outside prompt range")
    review_by_product[pid].append(r)

if any(c > 1 for c in title_counts.values()):
    errors.append("Duplicate review titles")
if any(c > 1 for c in body_counts.values()):
    errors.append("Duplicate review bodies")
if rating_counts != Counter({5: 1850, 4: 1750, 3: 750, 2: 400, 1: 250}):
    errors.append(f"Review rating distribution mismatch: {rating_counts}")
verified_pct = verified_count / len(reviews) * 100
if not (84.5 <= verified_pct <= 85.5):
    errors.append(f"Verified review percentage {verified_pct:.2f} outside expected range")

for p in products:
    revs = review_by_product[oid(p["_id"])]
    avg = round(sum(r["rating"] for r in revs) / len(revs), 1) if revs else 0
    rs = p["reviewSummary"]
    if rs["totalCount"] != len(revs) or abs(rs["averageRating"] - avg) > 0.05:
        errors.append(f"Product {p['sku']} reviewSummary mismatch")
    if p.get("isOutlier"):
        dist = {str(k): sum(1 for r in revs if r["rating"] == k) for k in range(1, 6)}
        top = sorted(revs, key=lambda r: (-r["helpful"], dstr(r["createdAt"]), oid(r["_id"])))[:3]
        expected_top = [{"customerName": r["customerName"], "rating": r["rating"], "title": r["title"]} for r in top]
        if rs.get("ratingDistribution") != dist or rs.get("topReviews") != expected_top or p.get("reviewsLocation") != "reviews":
            errors.append(f"Outlier product {p['sku']} review summary fields mismatch")

zero_review_products = sum(1 for p in products if len([r for r in reviews if oid(r["productId"]) == oid(p["_id"])]) == 0)
if zero_review_products != 200:
    errors.append(f"Expected exactly 200 zero-review products, found {zero_review_products}")
if sorted([len(review_by_product[oid(p["_id"])]) for p in outliers]) != [110, 115, 130, 142]:
    errors.append("Outlier review counts mismatch")

inv_by_product = defaultdict(list)
for inv in inventory:
    iid = oid(inv["_id"])
    pid = oid(inv["productId"])
    if pid not in prod_by_id or inv["productSku"] != prod_by_id[pid]["sku"]:
        errors.append(f"Inventory {iid} product reference mismatch")
    events = inv["events"]
    if not (2 <= len(events) <= 8):
        errors.append(f"Inventory {iid} event count outside 2-8")
    sold = -sum(e["quantity"] for e in events if e["type"] == "sale")
    restocked = sum(e["quantity"] for e in events if e["type"] == "restock")
    ds = inv["dailySummary"]
    if ds["totalSold"] != sold or ds["totalRestocked"] != restocked or ds["endQuantity"] != ds["startQuantity"] - sold + restocked or ds["endQuantity"] < 0:
        errors.append(f"Inventory {iid} dailySummary does not reconcile with events")
    inv_by_product[pid].append(inv)
if len(inv_by_product) != 30:
    errors.append("Inventory must cover exactly 30 products")
for pid, docs in inv_by_product.items():
    docs = sorted(docs, key=lambda d: dstr(d["date"]))
    if len(docs) != 30:
        errors.append(f"Inventory product {pid} does not have 30 daily buckets")
    if docs[0]["dailySummary"]["startQuantity"] != prod_by_id[pid]["inventory"]:
        errors.append(f"Inventory product {pid} first bucket does not start from product inventory")
    for a, b in zip(docs, docs[1:]):
        if a["dailySummary"]["endQuantity"] != b["dailySummary"]["startQuantity"]:
            errors.append(f"Inventory product {pid} bucket carry-forward mismatch")

unbounded = load("anti-patterns/products-unbounded-reviews.json")
if len(unbounded) != 15:
    errors.append("products-unbounded-reviews.json must contain 15 products")
types = Counter(p["productType"] for p in unbounded)
if any(types[t] < 2 for t in ["bike", "component", "accessory", "clothing"]):
    errors.append("products-unbounded-reviews.json does not include required product type mix")
if not any(len(p.get("reviews", [])) >= 100 for p in unbounded):
    errors.append("products-unbounded-reviews.json must include at least one outlier product")
if any("reviewSummary" in p for p in unbounded):
    errors.append("products-unbounded-reviews.json should remove reviewSummary")

over = load("anti-patterns/products-over-normalized.json")
if len(over) != 1000 or any(("category" in p or "tags" in p or "parentCategory" in p) for p in over):
    errors.append("products-over-normalized.json shape is incorrect")

mixed = load("anti-patterns/products-mixed-case.json")
if len(mixed) != 110:
    errors.append("products-mixed-case.json must contain 100 products plus 10 duplicate category-like entries")

sprawl_files = list((ROOT / "anti-patterns" / "sprawl-collections").glob("*.json"))
if len(sprawl_files) != 37 or sum(len(json.load(open(f, encoding="utf-8"))) for f in sprawl_files) != 1000:
    errors.append("sprawl-collections must contain all 1,000 products split across 37 category files")

if (ROOT / "anti-patterns" / "setup-unnecessary-indexes.js").read_text(encoding="utf-8").count("createIndex") < 20:
    errors.append("setup-unnecessary-indexes.js must create 20+ indexes")

if errors:
    print("DATASET_REMEDIATION_VALIDATION_FAILED")
    for e in errors[:200]:
        print("ERROR:", e)
    if len(errors) > 200:
        print(f"... {len(errors) - 200} additional errors omitted")
    sys.exit(1)

print("DATASET_REMEDIATION_VALIDATION_PASS_OK")
for name in ["categories", "tags", "products", "customers", "orders", "reviews", "inventory", "ordersArchive"]:
    print(f"{name}={len(collections[name])}")
print(f"fullOrders={full_orders}")
print(f"orderStubs={stub_orders}")
print(f"reviewRatingDistribution={dict(sorted(rating_counts.items()))}")
print(f"reviewVerifiedPercent={verified_pct:.2f}")
print(f"reviewTitleWordRange={min(wc(r['title']) for r in reviews)}-{max(wc(r['title']) for r in reviews)}")
print(f"reviewBodyWordRange={min(wc(r['body']) for r in reviews)}-{max(wc(r['body']) for r in reviews)}")
print(f"reviewSentenceDistribution={dict(sorted(Counter(sc(r['body']) for r in reviews).items()))}")
print(f"reviewUniqueTitles={len(title_counts)}")
print(f"reviewUniqueBodies={len(body_counts)}")
print("ANTI_PATTERN_ARTIFACTS_PASS_OK")
