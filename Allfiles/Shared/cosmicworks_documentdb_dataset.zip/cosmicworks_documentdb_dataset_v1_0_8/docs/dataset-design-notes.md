# Dataset design notes

## Supported module topics

- Relationship modeling: customers embed bounded addresses, orders embed owned line items, products reference categories through extended reference fields, reviews reference products and customers because review cardinality is unbounded.
- Schema design patterns: inheritance, computed, approximation, extended reference, schema versioning, subset, bucket, outlier, and archive patterns are present in the good dataset.
- Anti-pattern remediation: flawed variants cover unbounded arrays, collection sprawl, unnecessary indexes, over-normalization, and case-sensitivity issues.
- Index optimization: recommended indexes support equality-sort-range examples, multikey tag and line-item queries, review lookups, and archive lookup patterns.

## Collection boundaries

The collection boundaries reflect document-database ownership and access patterns, not relational normalization. The catalog stays in one `products` collection with `productType` and `specs`. Orders own their line items, so `items` is embedded. Reviews grow without a practical bound, so reviews remain separate and products keep only computed summaries. Inventory events are grouped into daily buckets instead of one event per document.
