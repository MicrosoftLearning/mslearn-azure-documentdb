// Load the AdventureWorks Cycles dataset into Azure DocumentDB / MongoDB-compatible database.
// Run from this package root with mongosh connected to your cluster:
//   mongosh "<connection-string>" --file load/load-dataset.js

use ecommerce

const fs = require('fs');
const path = require('path');

const root = path.resolve('.');
const collections = [
  'categories',
  'tags',
  'products',
  'customers',
  'orders',
  'reviews',
  'inventory',
  'ordersArchive'
];

for (const name of collections) {
  const filePath = path.join(root, 'collections', `${name}.json`);
  const docs = EJSON.parse(fs.readFileSync(filePath, 'utf8'));
  db.getCollection(name).drop();
  if (docs.length > 0) {
    db.getCollection(name).insertMany(docs);
  }
  print(`${name}: ${docs.length}`);
}

load(path.join(root, 'indexes', 'recommended-indexes.js'));
print('Dataset load complete.');
