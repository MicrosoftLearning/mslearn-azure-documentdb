// Anti-pattern: Unnecessary indexes on the products collection
// Each index consumes storage, slows writes, and uses RAM.
// Most of these indexes do not support actual query patterns.

use cosmicworks;

db.products.createIndex({ description: 1 });
db.products.createIndex({ createdAt: 1 });
db.products.createIndex({ isActive: 1 });
db.products.createIndex({ schemaVersion: 1 });
db.products.createIndex({ "specs.frameSize": 1 });
db.products.createIndex({ "specs.frameMaterial": 1 });
db.products.createIndex({ "specs.color": 1 });
db.products.createIndex({ "specs.weight_kg": 1 });
db.products.createIndex({ "specs.gears": 1 });
db.products.createIndex({ "specs.brakeType": 1 });
db.products.createIndex({ "specs.suspensionType": 1 });
db.products.createIndex({ "specs.wheelSize_inches": 1 });
db.products.createIndex({ inventory: 1 });
db.products.createIndex({ "approximateMetrics.viewCount": 1 });
db.products.createIndex({ "approximateMetrics.wishlistCount": 1 });
db.products.createIndex({ "approximateMetrics.cartAdditions": 1 });
db.products.createIndex({ "reviewSummary.averageRating": 1 });
db.products.createIndex({ "reviewSummary.totalCount": 1 });
db.products.createIndex({ parentCategory: 1 });
db.products.createIndex({ isOutlier: 1 });
db.products.createIndex({ price: 1 });
db.products.createIndex({ name: 1 });
db.products.createIndex({ name: 1, price: 1 });
db.products.createIndex({ "category.name": 1 });
db.products.createIndex({ tags: 1 });
db.products.createIndex({ productType: 1 });

print("Created " + db.products.getIndexes().length + " indexes on products collection");
print("Run db.products.aggregate([{$indexStats: {}}]) to see which are actually used");
