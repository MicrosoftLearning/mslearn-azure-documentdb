// Recommended indexes for the good AdventureWorks Cycles Azure DocumentDB dataset.
// Run in mongosh after loading the collection JSON files.
use ecommerce

db.products.createIndex({ sku: 1 }, { unique: true });
db.products.createIndex({ "category.name": 1, price: 1 });
db.products.createIndex({ parentCategory: 1, price: 1 });
db.products.createIndex({ productType: 1, price: 1 });
db.products.createIndex({ tags: 1 });
db.products.createIndex({ name: "text", description: "text" });
db.products.createIndex({ isOutlier: 1, "reviewSummary.totalCount": -1 });
db.products.createIndex({ "approximateMetrics.viewCount": -1 });

db.customers.createIndex({ email: 1 }, { unique: true });
db.customers.createIndex({ lastName: 1, firstName: 1 });
db.customers.createIndex({ "addresses.state": 1, "addresses.city": 1 });
db.customers.createIndex({ membershipTier: 1, orderCount: -1 });

db.orders.createIndex({ customerId: 1, orderDate: -1 });
db.orders.createIndex({ status: 1, orderDate: -1 });
db.orders.createIndex({ "items.sku": 1 });
db.orders.createIndex({ isFullyLoaded: 1, orderDate: -1 });

db.reviews.createIndex({ productId: 1, createdAt: -1 });
db.reviews.createIndex({ productId: 1, rating: -1, helpful: -1 });
db.reviews.createIndex({ customerId: 1, createdAt: -1 });

db.inventory.createIndex({ productId: 1, date: 1 }, { unique: true });
db.inventory.createIndex({ productSku: 1, date: 1 });

db.ordersArchive.createIndex({ originalOrderId: 1 }, { unique: true });
db.ordersArchive.createIndex({ customerId: 1, orderDate: -1 });
