# AdventureWorks Cycles MongoDB Dataset for Azure DocumentDB

This package contains a MongoDB-style document dataset for the Azure DocumentDB learning path. It is organized as one JSON file per collection under `collections/`.

## Collections

| Collection | Documents | Purpose |
|---|---:|---|
| `categories` | 37 | Product category reference data |
| `tags` | 50 | Product tag reference data |
| `products` | 1000 | Single product catalog collection with inheritance-style `specs` |
| `customers` | 249 | Customer profiles with embedded bounded addresses and recent-order subset |
| `orders` | 4000 | Active order collection with embedded full orders and archive stubs |
| `reviews` | 5000 | Separate review collection for unbounded review cardinality |
| `inventory` | 900 | Daily bucket documents for the 30 highest-viewed products |
| `ordersArchive` | 1613 | Archived full order documents for cold terminal orders |

## MongoDB-style design choices

The dataset is intentionally not relational. Product documents embed display-ready category references and tag names. Orders embed owned line items and shipping-address snapshots. Customers embed a bounded address array and the five most recent orders as a subset. Reviews remain in a separate collection because review growth is unbounded. Inventory uses bucket documents. Older terminal orders demonstrate the archive pattern by keeping stubs in `orders` and full documents in `ordersArchive`.

## Remediation status in v1.0.6

This version was rechecked against both the original dataset prompt and the remediation prompt. Additional fixes were applied after v1.0.5:

- Customer names now exactly match the approved FNF full-name list included in `validation/approved-fictitious-fullnames.txt`.
- Product prices and inventory values are inside the original prompt ranges.
- Product descriptions are unique, 2-3 sentences, cycling-specific, and do not reference dataset or exercise context.
- Orders contain 2387 full documents and 1613 archive stubs according to the date/status rule.
- Full orders and archive orders use shipping-address snapshots without the customer address `label` field.
- Reviews have unique titles and bodies, 5-10 word titles, 40-120 word bodies, and 2-4 sentence single-paragraph text.
- Inventory bucket summaries reconcile exactly with their embedded events.
- Anti-pattern artifacts were rebuilt from the corrected collections.

## Review text quality

Review documents use deterministic but varied customer-review prose. Titles avoid SKUs, generated note numbers, and metadata-style wording. Bodies vary by product type, rating, category, and product specifications so they can support query, aggregation, text-search, and outlier-pattern exercises without sounding like repeated fixture text.

## Intentional anti-pattern data

The `anti-patterns/` folder includes flawed variants for remediation exercises:

- `products-unbounded-reviews.json`
- `products-over-normalized.json`
- `products-mixed-case.json`
- `sprawl-collections/`
- `setup-unnecessary-indexes.js`

These files are intentionally flawed. Do not load them into the main exercise database unless the exercise specifically asks for anti-pattern data.

## Loading

From the package root, use:

```bash
mongosh "<connection-string>" load/load-dataset.js
```

The load script expects the collection files under `collections/` and inserts each JSON array into its matching collection.

## Validation

From the package root, run:

```bash
python3 validation/validate_dataset.py
```

Expected marker:

```text
DATASET_REMEDIATION_VALIDATION_PASS_OK
```


## v1.0.8 final-round remediation

- Regenerated all review titles and bodies with type-specific content boundaries.
- Updated outlier topReviews from the regenerated reviews.
- Rebuilt the embedded unbounded-review anti-pattern examples from the corrected review text.
- Ensured `products-mixed-case.json` ends with 10 duplicate category-like records, using valid hexadecimal ObjectIds.
- Confirmed `products-over-normalized.json` contains no `parentCategory` fields.


## Final polish patch v1.0.8

This patch updates only five review `title` and `body` fields to correct product-type inconsistencies and grammar issues identified after v1.0.7. Review identifiers, product/customer references, ratings, helpful counts, verified flags, dates, and all other collections are unchanged from v1.0.7.
